"""
cv_server.py
────────────
Flask microservice wrapping cv_module for a browser-based interview UI.

Architecture:
    Browser owns the camera (getUserMedia) and shows live video natively.
    Every ~350ms it posts ONE still frame here for analysis.
    This server never displays or streams video — it only returns JSON.

Run:
    pip install flask
    python backend/cv_server.py

Then open frontend/interview_camera.html in a browser (or serve it from
your actual frontend app) — it talks to this server on port 5050.

CORS:
    A permissive header is added below so the frontend can run on a
    different port/origin during development (e.g. opened as a local
    file, or served by a dev server like Vite on port 5173).
    Tighten Access-Control-Allow-Origin to your real frontend domain
    before deploying.
"""

import sys
import os
import base64

# Allow running this file directly — makes `cv_module` importable
# regardless of the current working directory.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from flask import Flask, request, jsonify, session
from werkzeug.security import check_password_hash, generate_password_hash

from cv_module import CVPipeline
from cv_module.feedback_generator import generate_session_feedback
import db


app = Flask(__name__)
app.secret_key = os.environ.get('CAREERBOOST_SECRET_KEY', 'dev-careerboost-secret')
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
)

# camera_index=None — this server has no physical webcam of its own.
# The browser owns the camera; frames arrive via /cv/analyze-frame.
cv = CVPipeline(camera_index=None, enable_face_mesh=True)

# ── Database ────────────────────────────────────────────────────────────────
# Creates careerboost.db (next to this file) on first run if it doesn't
# exist yet, and ensures a demo user is available for local testing.
db.init_db()
DEMO_USER_ID = db.ensure_demo_user()


ALLOWED_ORIGINS = {
    'http://localhost:8080',
    'http://127.0.0.1:8080',
}


def current_user():
    user_id = session.get('user_id')
    if not user_id:
        return None

    user = db.get_user_by_id(user_id)
    if not user:
        session.pop('user_id', None)
        session.pop('current_session_id', None)
        session.pop('current_q_number', None)
    return user


def require_user():
    user = current_user()
    if not user:
        return None, (jsonify({'error': 'authentication required'}), 401)
    return user, None


# ── CORS (development-friendly — restrict before deploying) ───────────────────
# IMPORTANT: routes below intentionally do NOT list 'OPTIONS' in their
# methods. Flask auto-generates a lightweight OPTIONS response for any
# route that doesn't explicitly claim it. If we claimed OPTIONS ourselves,
# the browser's CORS preflight (an empty-body OPTIONS request) would be
# routed into our view functions, which call request.get_json(force=True)
# and crash on the empty preflight body — silently blocking every real
# POST request afterward. Leaving OPTIONS unclaimed avoids this entirely.
@app.after_request
def add_cors_headers(response):
    origin = request.headers.get('Origin')
    if origin in ALLOWED_ORIGINS:
        response.headers['Access-Control-Allow-Origin'] = origin
        response.headers['Vary'] = 'Origin'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    response.headers['Access-Control-Allow-Credentials'] = 'true'
    return response


# ── Authentication ───────────────────────────────────────────────────────────
@app.route('/auth/register', methods=['POST'])
def register():
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get('email') or '').strip().lower()
    password = data.get('password') or ''
    name = (data.get('name') or data.get('fullname') or '').strip()

    if not email or not password or not name:
        return jsonify({'error': 'name, email, and password are required'}), 400

    if db.get_user_by_email(email):
        return jsonify({'error': 'email is already registered'}), 409

    password_hash = generate_password_hash(password)
    user_id = db.create_user(email, password_hash, name)
    user = db.get_user_by_id(user_id)

    session['user_id'] = user_id
    return jsonify({'status': 'ok', 'user': {
        'id': user['id'],
        'email': user['email'],
        'name': user['name'],
        'created_at': user['created_at'],
    }})


@app.route('/auth/login', methods=['POST'])
def login():
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get('email') or '').strip().lower()
    password = data.get('password') or ''

    if not email or not password:
        return jsonify({'error': 'email and password are required'}), 400

    user = db.get_user_by_email(email)
    if not user or not check_password_hash(user['password_hash'], password):
        return jsonify({'error': 'invalid email or password'}), 401

    session['user_id'] = user['id']
    return jsonify({'status': 'ok', 'user': {
        'id': user['id'],
        'email': user['email'],
        'name': user['name'],
        'created_at': user['created_at'],
    }})


@app.route('/auth/me', methods=['GET'])
def me():
    user = current_user()
    if not user:
        return jsonify({'error': 'not authenticated'}), 401

    return jsonify({'user': {
        'id': user['id'],
        'email': user['email'],
        'name': user['name'],
        'created_at': user['created_at'],
    }})


@app.route('/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'status': 'ok'})


# ── Session lifecycle ──────────────────────────────────────────────────────────
@app.route('/cv/session/start', methods=['POST'])
def start_session():
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    data     = request.get_json(force=True, silent=True) or {}
    job_role = data.get('job_role', '')

    cv.start_session()
    session['current_session_id'] = db.create_session(user['id'], job_role)
    session['current_q_number'] = 0

    print(f"[session/start] db session_id={session['current_session_id']}")
    return jsonify({'status': 'ok', 'session_id': session['current_session_id']})


@app.route('/cv/question/start', methods=['POST'])
def start_question():
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    data = request.get_json(force=True, silent=True) or {}
    question_id   = data.get('question_id')
    question_text = data.get('question_text', '')

    if question_id is None:
        return jsonify({'error': 'question_id is required'}), 400

    session['current_q_number'] = session.get('current_q_number', 0) + 1
    cv.start_question(question_id, question_text)
    print(f"[question/start] id={question_id} recording={cv._recording}")
    return jsonify({'status': 'recording'})


@app.route('/cv/question/end', methods=['POST'])
def end_question():
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    report = cv.end_question()

    db_question_id = None
    current_session_id = session.get('current_session_id')
    current_q_number = session.get('current_q_number', 0)

    if current_session_id is not None:
        db_question_id = db.save_question_report(
            session_id      = current_session_id,
            question_number = current_q_number,
            question_text   = report.get('question_text', ''),
            cv_report       = report,
        )
        print(f"[question/end] saved db question_id={db_question_id}")

    report['db_question_id'] = db_question_id   # audio module uses this to attach its transcript
    return jsonify(report)


@app.route('/cv/session/end', methods=['POST'])
def end_session():
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    summary  = cv.end_session()
    feedback = generate_session_feedback(summary)

    current_session_id = session.get('current_session_id')
    if current_session_id is not None:
        db.finish_session(current_session_id, feedback['overall_cv_score'])
        print(f"[session/end] db session_id={current_session_id} finalized")

    feedback['session_id'] = current_session_id
    session.pop('current_session_id', None)
    session.pop('current_q_number', None)
    return jsonify(feedback)


# ── Per-frame analysis (the core endpoint for the browser-camera flow) ───────
@app.route('/cv/analyze-frame', methods=['POST'])
def analyze_frame():
    """
    Body:
        { "frame": "data:image/jpeg;base64,/9j/4AAQ..." }

    Returns:
        {
          "face_detected":  true,
          "top_emotion":    "neutral",
          "top_confidence": 0.71,
          "eye_contact":    true,
          "gaze_direction": "camera"
        }

    Called repeatedly (every ~300-500ms recommended) while a question
    is being recorded. If called between questions (no active
    recording), it still analyzes the frame but does not store it.
    """
    data = request.get_json(force=True, silent=True) or {}
    data_url = data.get('frame', '')

    if not data_url:
        return jsonify({'error': 'missing "frame" field'}), 400

    # Strip the "data:image/jpeg;base64," prefix if present
    b64_data = data_url.split(',', 1)[1] if ',' in data_url else data_url

    try:
        image_bytes = base64.b64decode(b64_data)
    except Exception:
        return jsonify({'error': 'invalid base64 image data'}), 400

    result = cv.analyze_frame(image_bytes)
    print(f"[analyze-frame] face_detected={result.get('face_detected')} "
          f"emotion={result.get('top_emotion')} recording={cv._recording}")
    return jsonify(result)


# ── Reads — feed the Interview Practice table and analytics.html ────────────
@app.route('/sessions', methods=['GET'])
def list_sessions():
    """Past interview sessions for the signed-in user, most recent first."""
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    sessions = db.get_user_sessions(user['id'])
    return jsonify(sessions)


@app.route('/sessions/<int:session_id>', methods=['GET'])
def session_detail(session_id):
    """One session with all its questions — CV reports + transcripts."""
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    detail = db.get_session_detail(session_id)
    if detail is None:
        return jsonify({'error': 'session not found'}), 404
    if detail.get('user_id') != user['id']:
        return jsonify({'error': 'session not found'}), 404
    return jsonify(detail)


@app.route('/questions', methods=['GET'])
def list_questions():
    """
    Returns the question bank for a role — used by interview-session.js
    instead of a hardcoded array. Stands in for the NLP Question
    Generation module until that exists.

    Query param: ?role=Software Engineer  (optional, defaults to General)
    """
    job_role = request.args.get('role', 'General')
    questions = db.get_questions_for_role(job_role)
    return jsonify(questions)


@app.route('/users/me/stats', methods=['GET'])
def user_stats():
    """Aggregate stats for the dashboard — interviews completed, avg score."""
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    stats = db.get_user_stats(user['id'])
    return jsonify(stats)


# ── Audio module integration point ──────────────────────────────────────────
@app.route('/questions/<int:question_id>/transcript', methods=['POST'])
def attach_transcript(question_id):
    """
    For the speech/audio teammate's service to call once it has finished
    transcribing an answer. Uses the db_question_id returned by
    /cv/question/end to attach to the right row — no other coordination
    with the CV module needed.

    Body: { "text": "...", "any_other_fields": "..." }
    """
    user, auth_error = require_user()
    if auth_error:
        return auth_error

    transcript = request.get_json(force=True, silent=True) or {}
    db.update_transcript(question_id, transcript)
    return jsonify({'status': 'ok'})


if __name__ == '__main__':
    print('CV server starting on http://localhost:5050')
    print('Endpoints:')
    print('  POST /auth/register')
    print('  POST /auth/login')
    print('  POST /auth/logout')
    print('  GET  /auth/me')
    print('  POST /cv/session/start')
    print('  POST /cv/question/start   { question_id, question_text }')
    print('  POST /cv/analyze-frame    { frame: data-url }')
    print('  POST /cv/question/end')
    print('  POST /cv/session/end')
    print('  GET  /sessions')
    print('  GET  /sessions/<id>')
    print('  GET  /questions?role=...')
    print('  GET  /users/me/stats')
    print('  POST /questions/<id>/transcript')
    app.run(host='0.0.0.0', port=5050, debug=False)
