"""
db.py
─────
SQLite persistence layer for CareerBoost.

Three tables:
  users      — candidate accounts. Until real login/register is wired up,
               a single "demo user" is auto-created and reused so sessions
               have somewhere to attach.
  sessions   — one row per interview attempt (start time, end time, score).
  questions  — one row per question within a session. Holds the CV
               module's full report as JSON, and a transcript column
               reserved for the audio/speech module to fill in later —
               both attach to the same question_id, which is how the
               two independent modules end up describing the same answer.

Run this file directly once to create careerboost.db:
    python backend/db.py
"""

import sqlite3
import json
import os
from datetime import datetime, timezone
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'careerboost.db')

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name          TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL,
    job_role       TEXT,
    started_at     TEXT NOT NULL,
    ended_at       TEXT,
    overall_score  REAL,
    FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE IF NOT EXISTS questions (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id       INTEGER NOT NULL,
    question_number  INTEGER NOT NULL,
    question_text    TEXT,
    cv_report        TEXT,
    transcript       TEXT,
    duration_seconds REAL,
    FOREIGN KEY (session_id) REFERENCES sessions (id)
);

CREATE TABLE IF NOT EXISTS question_bank (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    job_role  TEXT NOT NULL,
    text      TEXT NOT NULL
);
"""

# Seeded once on first run — replace/extend this with the real NLP Question
# Generation module's output whenever that module is ready. Until then this
# is a real database table instead of a hardcoded array in the frontend JS.
DEFAULT_QUESTIONS = [
    ('General', 'Tell me about yourself.'),
    ('General', 'What is your greatest professional strength?'),
    ('General', 'Describe a challenge you faced and how you overcame it.'),
    ('General', 'Where do you see yourself in five years?'),
    ('General', 'Why should we hire you for this role?'),
    ('Software Engineer', 'Walk me through how you would design a URL shortener.'),
    ('Software Engineer', 'Tell me about a bug that was hard to track down.'),
    ('Software Engineer', 'How do you approach code review feedback you disagree with?'),
    ('Backend Developer', 'How would you design a rate limiter for an API?'),
    ('Backend Developer', 'Describe how you would debug a slow database query.'),
    ('Data Scientist', 'Walk me through how you would handle a heavily imbalanced dataset.'),
    ('Data Scientist', 'How do you explain a model\u2019s prediction to a non-technical stakeholder?'),
]

DEMO_EMAIL = 'demo@careerboost.local'
DEMO_PASSWORD = 'demo123'


# ── Connection ─────────────────────────────────────────────────────────────
def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db():
    """Creates the database file and tables if they don't already exist."""
    conn = get_connection()
    conn.executescript(SCHEMA)
    conn.commit()
    ensure_demo_user(conn)
    _seed_question_bank(conn)
    conn.close()
    print(f'[db] Ready at {DB_PATH}')


def _seed_question_bank(conn: sqlite3.Connection):
    """Populates question_bank once, only if it's currently empty."""
    count = conn.execute('SELECT COUNT(*) AS c FROM question_bank').fetchone()['c']
    if count == 0:
        conn.executemany(
            'INSERT INTO question_bank (job_role, text) VALUES (?, ?)',
            DEFAULT_QUESTIONS
        )
        conn.commit()


def ensure_demo_user(conn: sqlite3.Connection = None) -> int:
    """
    Creates a single demo user the first time the app runs, so interview
    sessions have a user_id to attach to before real auth exists.
    Safe to call repeatedly — returns the same id every time.
    """
    own_conn = conn is None
    if own_conn:
        conn = get_connection()

    row = conn.execute(
        'SELECT id, password_hash FROM users WHERE email = ?', (DEMO_EMAIL,)
    ).fetchone()

    demo_password_hash = generate_password_hash(DEMO_PASSWORD)

    if row:
        user_id = row['id']
        if not check_password_hash(row['password_hash'], DEMO_PASSWORD):
            conn.execute(
                'UPDATE users SET password_hash = ?, name = ? WHERE id = ?',
                (demo_password_hash, 'Demo Candidate', user_id)
            )
            conn.commit()
    else:
        cur = conn.execute(
            'INSERT INTO users (email, password_hash, name, created_at) '
            'VALUES (?, ?, ?, ?)',
            (DEMO_EMAIL, demo_password_hash, 'Demo Candidate',
             datetime.now(timezone.utc).isoformat())
        )
        conn.commit()
        user_id = cur.lastrowid

    if own_conn:
        conn.close()
    return user_id


def get_user_by_email(email: str):
    conn = get_connection()
    row = conn.execute(
        'SELECT id, email, password_hash, name, created_at FROM users WHERE email = ?',
        (email.strip().lower(),)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_id(user_id: int):
    conn = get_connection()
    row = conn.execute(
        'SELECT id, email, password_hash, name, created_at FROM users WHERE id = ?',
        (user_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def create_user(email: str, password_hash: str, name: str) -> int:
    conn = get_connection()
    cur = conn.execute(
        'INSERT INTO users (email, password_hash, name, created_at) VALUES (?, ?, ?, ?)',
        (email.strip().lower(), password_hash, name.strip(), datetime.now(timezone.utc).isoformat())
    )
    conn.commit()
    user_id = cur.lastrowid
    conn.close()
    return user_id


# ── Question bank ─────────────────────────────────────────────────────────
def get_questions_for_role(job_role: str) -> list:
    """
    Returns General questions plus any matching the given role.
    Stands in for the NLP Question Generation module until it exists —
    a real table instead of a hardcoded array in the frontend JS.
    """
    conn = get_connection()
    rows = conn.execute(
        'SELECT id, text FROM question_bank WHERE job_role = ? OR job_role = ? '
        'ORDER BY job_role, id',
        (job_role or 'General', 'General')
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Dashboard stats (used by index.html) ───────────────────────────────────
def get_user_stats(user_id: int) -> dict:
    conn = get_connection()
    row = conn.execute(
        'SELECT COUNT(*) AS total, AVG(overall_score) AS avg_score '
        'FROM sessions WHERE user_id = ? AND ended_at IS NOT NULL',
        (user_id,)
    ).fetchone()
    conn.close()
    return {
        'interviews_completed': row['total'] or 0,
        'avg_confidence_score': round(row['avg_score'], 1) if row['avg_score'] is not None else None,
    }


# ── Session lifecycle ─────────────────────────────────────────────────────
def create_session(user_id: int, job_role: str = '') -> int:
    """Call when an interview begins. Returns the new session id."""
    conn = get_connection()
    cur = conn.execute(
        'INSERT INTO sessions (user_id, job_role, started_at) VALUES (?, ?, ?)',
        (user_id, job_role, datetime.now(timezone.utc).isoformat())
    )
    conn.commit()
    session_id = cur.lastrowid
    conn.close()
    return session_id


def save_question_report(session_id: int, question_number: int,
                          question_text: str, cv_report: dict,
                          transcript: dict = None) -> int:
    """
    Call after cv.end_question() returns its report.
    transcript stays None until the audio module writes it in separately
    (see update_transcript below) — the two modules don't need to
    coordinate timing, they just both target the same question row.
    """
    conn = get_connection()
    cur = conn.execute(
        'INSERT INTO questions '
        '(session_id, question_number, question_text, cv_report, transcript, duration_seconds) '
        'VALUES (?, ?, ?, ?, ?, ?)',
        (
            session_id,
            question_number,
            question_text,
            json.dumps(cv_report),
            json.dumps(transcript) if transcript else None,
            cv_report.get('duration_seconds'),
        )
    )
    conn.commit()
    question_id = cur.lastrowid
    conn.close()
    return question_id


def update_transcript(question_id: int, transcript: dict):
    """
    For the audio/speech module to call once it has finished transcribing
    a question's answer. Attaches to the question row your CV module
    already created — no coordination needed beyond knowing question_id.
    """
    conn = get_connection()
    conn.execute(
        'UPDATE questions SET transcript = ? WHERE id = ?',
        (json.dumps(transcript), question_id)
    )
    conn.commit()
    conn.close()


def finish_session(session_id: int, overall_score: float):
    """Call after cv.end_session() / generate_session_feedback()."""
    conn = get_connection()
    conn.execute(
        'UPDATE sessions SET ended_at = ?, overall_score = ? WHERE id = ?',
        (datetime.now(timezone.utc).isoformat(), overall_score, session_id)
    )
    conn.commit()
    conn.close()


# ── Reads — used by the Interview Practice table and analytics.html ───────
def get_user_sessions(user_id: int) -> list:
    """Returns past sessions, most recent first — feeds the practice history table."""
    conn = get_connection()
    rows = conn.execute(
        'SELECT id, job_role, started_at, ended_at, overall_score '
        'FROM sessions WHERE user_id = ? ORDER BY started_at DESC',
        (user_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_session_detail(session_id: int) -> dict | None:
    """Returns one session plus all of its questions, CV reports parsed back to dicts."""
    conn = get_connection()
    session = conn.execute(
        'SELECT * FROM sessions WHERE id = ?', (session_id,)
    ).fetchone()

    if not session:
        conn.close()
        return None

    questions = conn.execute(
        'SELECT * FROM questions WHERE session_id = ? ORDER BY question_number',
        (session_id,)
    ).fetchall()
    conn.close()

    result = dict(session)
    result['questions'] = []
    for q in questions:
        q_dict = dict(q)
        q_dict['cv_report']  = json.loads(q_dict['cv_report'])  if q_dict['cv_report']  else None
        q_dict['transcript'] = json.loads(q_dict['transcript']) if q_dict['transcript'] else None
        result['questions'].append(q_dict)
    return result


if __name__ == '__main__':
    init_db()
    demo_id = ensure_demo_user()
    print(f'[db] Demo user id: {demo_id}')
