/* ============================================
   Live Interview Session — CV Module Integration
   Talks to cv_server.py (Flask) on port 5050
   Browser owns the camera via getUserMedia — the
   backend never displays or streams video, it only
   analyzes still frames posted to /cv/analyze-frame.
============================================ */

(function () {
    'use strict';

    // ── Configuration ────────────────────────────────────────────────────────
    const BACKEND = 'http://localhost:5050';
    const FRAME_INTERVAL_MS = 350;

    // Job role comes from the URL — users.html passes it when "Start
    // Interview" is clicked, e.g. interview-session.html?role=Software%20Engineer
    const JOB_ROLE = new URLSearchParams(window.location.search).get('role') || 'General';

    // Loaded from the real question bank on startup — see loadQuestions().
    let QUESTIONS = [];

    // ── State ────────────────────────────────────────────────────────────────
    let qIndex = 0;
    let captureInterval = null;
    let timerInterval = null;
    let seconds = 0;
    let stream = null;

    // ── DOM references ──────────────────────────────────────────────────────
    const video        = document.getElementById('video');
    const canvas       = document.getElementById('canvas');
    const ctx           = canvas.getContext('2d');
    const ring          = document.getElementById('ring');
    const qBadge        = document.getElementById('qBadge');
    const qPill         = document.getElementById('qPill');
    const qText         = document.getElementById('qText');
    const timerEl       = document.getElementById('timer');
    const statusText    = document.getElementById('statusText');
    const finishBtn     = document.getElementById('finishBtn');
    const nextBtn       = document.getElementById('nextBtn');
    const liveStage     = document.getElementById('liveStage');
    const summaryStage  = document.getElementById('summaryStage');
    const summarySub    = document.getElementById('summarySub');

    function formatTime(s) {
        const m = String(Math.floor(s / 60)).padStart(2, '0');
        const sec = String(s % 60).padStart(2, '0');
        return `${m}:${sec}`;
    }

    function capitalize(s) {
        return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
    }

    // ── Backend calls ───────────────────────────────────────────────────────
    async function postJSON(path, body) {
        const res = await fetch(`${BACKEND}${path}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: body ? JSON.stringify(body) : undefined,
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
            const err = new Error(data.error || `Request failed (${res.status})`);
            err.status = res.status;
            throw err;
        }
        return data;
    }

    async function getJSON(path) {
        const res = await fetch(`${BACKEND}${path}`, { credentials: 'include' });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
            const err = new Error(data.error || `Request failed (${res.status})`);
            err.status = res.status;
            throw err;
        }
        return data;
    }

    // ── Question bank ────────────────────────────────────────────────────────
    async function loadQuestions() {
        const rows = await getJSON(`/questions?role=${encodeURIComponent(JOB_ROLE)}`);
        QUESTIONS = rows.map((r) => ({ id: r.id, text: r.text }));
        if (QUESTIONS.length === 0) {
            throw new Error('No interview questions are available for this role yet.');
        }
    }

    // ── Camera ──────────────────────────────────────────────────────────────
    async function initCamera() {
        try {
            stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
            video.srcObject = stream;
            statusText.textContent = 'Camera connected — you can begin when ready.';
            finishBtn.disabled = false;
        } catch (err) {
            statusText.textContent = 'Camera access denied or unavailable. Check browser permissions.';
            console.error('[CV] getUserMedia failed:', err);
        }
    }

    function captureAndSendFrame() {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const frame = canvas.toDataURL('image/jpeg', 0.7);
        postJSON('/cv/analyze-frame', { frame })
            .then((data) => {
                ring.classList.toggle('detected', !!data.face_detected);
            })
            .catch(() => { /* transient network hiccup — skip silently */ });
    }

    // ── Interview flow ─────────────────────────────────────────────────────
    async function startInterview() {
        try {
            statusText.textContent = 'Loading interview questions…';
            await loadQuestions();
            await initCamera();
            await postJSON('/cv/session/start', { job_role: JOB_ROLE });
            await startQuestion();
        } catch (error) {
            if (error.status === 401) {
                window.location.href = 'login.html';
                return;
            }
            statusText.textContent = error.message || 'Unable to start the interview session.';
            finishBtn.disabled = true;
            console.error('[CV] startInterview failed:', error);
        }
    }

    async function startQuestion() {
        const q = QUESTIONS[qIndex];
        const label = `Question ${qIndex + 1} of ${QUESTIONS.length}`;

        qBadge.textContent = label;
        qPill.textContent  = label;
        qText.textContent  = q.text;
        seconds = 0;
        timerEl.textContent = '00:00';

        try {
            await postJSON('/cv/question/start', { question_id: q.id, question_text: q.text });
        } catch (error) {
            statusText.textContent = error.message || 'Unable to start question recording.';
            console.error('[CV] startQuestion failed:', error);
            return;
        }

        captureInterval = setInterval(captureAndSendFrame, FRAME_INTERVAL_MS);
        timerInterval   = setInterval(() => {
            seconds += 1;
            timerEl.textContent = formatTime(seconds);
        }, 1000);
    }

    async function finishQuestion() {
        clearInterval(captureInterval);
        clearInterval(timerInterval);
        finishBtn.disabled = true;

        const report = await postJSON('/cv/question/end');
        showSummary(report);
        finishBtn.disabled = false;
    }

    const EMOTION_COLORS = {
        angry: '#dc4040', disgust: '#3a9d4f', fear: '#9b59b6',
        happy: '#f0c419', neutral: '#9c9a92', sad: '#4a90d9', surprise: '#e8973f',
    };

    function renderEmotionBreakdown(breakdown) {
        const container = document.getElementById('mEmotions');
        if (!breakdown || breakdown.length === 0) {
            container.innerHTML = '<span style="color:var(--text-muted); font-size:13px;">No data</span>';
            return;
        }
        container.innerHTML = breakdown.map((e) => {
            const color = EMOTION_COLORS[e.emotion] || '#9c9a92';
            return `
                <div style="display:flex; align-items:center; gap:10px;">
                    <span style="width:80px; font-size:13px; flex-shrink:0;">${capitalize(e.emotion)}</span>
                    <div style="flex:1; background:rgba(255,255,255,0.08); border-radius:6px; height:8px; overflow:hidden;">
                        <div style="width:${e.pct}%; background:${color}; height:100%;"></div>
                    </div>
                    <span style="width:42px; text-align:right; font-size:13px; color:var(--text-muted);">${e.pct}%</span>
                </div>`;
        }).join('');
    }

    function showSummary(report) {
        document.getElementById('mEye').textContent =
            `${Math.round(report.eye_contact_pct)}%`;
        document.getElementById('mComp').textContent =
            report.emotion_switch_rate < 0.08 ? 'Stable' : 'Moderate';
        renderEmotionBreakdown(report.emotion_breakdown);
        document.getElementById('mStress').textContent =
            report.peak_stress.stress_value > 0.4 ? 'High'
            : report.peak_stress.stress_value > 0.2 ? 'Moderate' : 'Low';

        summarySub.textContent = `Question ${qIndex + 1} of ${QUESTIONS.length} complete`;
        liveStage.style.display = 'none';
        summaryStage.style.display = 'block';
    }

    async function nextQuestion() {
        summaryStage.style.display = 'none';
        liveStage.style.display = 'block';
        qIndex += 1;

        if (qIndex >= QUESTIONS.length) {
            const feedback = await postJSON('/cv/session/end');
            stream.getTracks().forEach((t) => t.stop());
            // Redirect with the real session_id — analytics.html fetches
            // GET /sessions/<id> to show the full per-question breakdown,
            // not just a single score number.
            window.location.href =
                `analytics.html?session=${feedback.session_id}`;
            return;
        }
        await startQuestion();
    }

    finishBtn.addEventListener('click', finishQuestion);
    nextBtn.addEventListener('click', nextQuestion);

    startInterview();
})();
